function SXR_spectr_calc(ne,Te,Ni);

Ew_arr=300:10:3000;

if nargin<3
    [Ni,Zeff]=Zeff_calc_manual(ne);
end;

J=zeros(size(Ew_arr));
for i=1:max(size(Ni))
    Z=Ni(i,1);
    ni=Ni(i,2)*ne;
    j(:,i)=J_calc(ne,ni,Z,Te,Ew_arr);
    J(:)=J(:)+j(:,i);
end;    
cm=colormap(hsv(max(size(Ni))));
figure;
    semilogy(Ew_arr,J(:),'.-r','LineWidth',1);
    hold on;
    for i=1:max(size(Ni))
        semilogy(Ew_arr,j(:,i),'Color',cm(i,:),'LineWidth',i);
    end;
        
