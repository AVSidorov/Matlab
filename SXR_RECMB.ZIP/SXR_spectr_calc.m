function SXR_spectr_calc(ne,Te,Ni);

Ew_arr=30:10:10000;

if nargin<3
    %[Ni,Zeff]=Zeff_calc_manual(ne);
    Ni=Species_by_Zeff;
end;

Jb=zeros(size(Ew_arr));
Jr=zeros(size(Ew_arr));
for i=1:max(size(Ni))
    Z=Ni(i,1);
    ni=Ni(i,2)*ne;
    [jb(:,i),jr(:,i)]=J_calc(ne,ni,Z,Te,Ew_arr);
    Jb(:)=Jb(:)+jb(:,i);
    Jr(:)=Jr(:)+jr(:,i);
end;    

figure;
    semilogy(Ew_arr,Jb(:),'-g','LineWidth',1);
    hold on;
    semilogy(Ew_arr,Jr(:),'-b','LineWidth',1);
    semilogy(Ew_arr,Jb(:)+Jr(:),'-r','LineWidth',2);
    semilogy(Ew_arr,jb(:,find(Ni(:,1)==1)),'-c','LineWidth',1);
        
